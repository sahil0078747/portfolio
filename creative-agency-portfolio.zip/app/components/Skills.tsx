"use client"

import { motion } from "framer-motion"

const skills = [
  { name: "HTML5", icon: "✅", color: "from-orange-500 to-red-500" },
  { name: "CSS3", icon: "🎨", color: "from-blue-500 to-cyan-500" },
  { name: "JavaScript", icon: "⚙️", color: "from-yellow-500 to-orange-500" },
  { name: "TailwindCSS", icon: "🌪️", color: "from-teal-500 to-blue-500" },
  { name: "GitHub", icon: "🐱", color: "from-gray-500 to-gray-700" },
  { name: "React", icon: "📚", color: "from-blue-400 to-blue-600", learning: true },
  { name: "Solidity", icon: "📚", color: "from-purple-500 to-pink-500", learning: true },
  { name: "Blockchain", icon: "📚", color: "from-green-500 to-teal-500", learning: true },
]

export default function Skills() {
  return (
    <section id="skills" className="section-padding bg-background/50">
      <div className="mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-gradient bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent">
              Skills & Tech Stack
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Technologies I work with and continuously learning new ones
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              className="tech-icon relative group"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className="bg-card/50 backdrop-blur-sm rounded-2xl p-6 border border-border/50 hover:border-primary/50 transition-all duration-300 h-full">
                <div className="text-center">
                  <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                    {skill.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-foreground">{skill.name}</h3>
                  {skill.learning && (
                    <span className="inline-block px-2 py-1 bg-primary/20 text-primary rounded-full text-xs font-medium">
                      Learning
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Learning Section */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="bg-gradient-to-r from-primary/10 to-blue-500/10 rounded-2xl p-8 border border-primary/20">
            <h3 className="text-2xl font-bold mb-4 text-foreground">Always Learning</h3>
            <p className="text-muted-foreground mb-6">
              I believe in continuous improvement and staying updated with the latest technologies. Currently expanding
              my skills in React, Solidity, and Blockchain development.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              {["Next.js", "TypeScript", "Web3.js", "Smart Contracts", "DeFi"].map((tech) => (
                <span key={tech} className="px-4 py-2 bg-primary/20 text-primary rounded-full text-sm font-medium">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
